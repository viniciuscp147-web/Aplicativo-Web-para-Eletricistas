# Eletric Calculator — versão Web

Conversão do app Android (Kotlin / Jetpack Compose) para web, mantendo as mesmas
telas, fórmulas (NBR 5410), tabelas de fornecedores e textos.

## Como usar
- **No computador:** abra `web/index.html` com um duplo clique (Chrome, Edge, Firefox, Safari).
- **Para publicar online:** envie o conteúdo da pasta `web/` para qualquer hospedagem
  estática (Netlify, Vercel, GitHub Pages, Firebase Hosting). Não precisa de servidor nem de build.

## Estrutura
- `web/index.html` — o app web completo (HTML + CSS + JavaScript em um só arquivo).
- `android-original/` — código-fonte Android original, intacto, como referência.

## O que mudou por ser web
- Banco Room e SharedPreferences viraram `localStorage` do navegador
  (os dados ficam no navegador de cada pessoa, sem sincronização entre aparelhos).
- Botão WhatsApp usa o compartilhamento do navegador (ou WhatsApp Web).
- `TechnicalGuideScreen.kt` não entra: nenhuma parte do app Android a chamava.

## Observação
O botão "Continuar com o Google" é uma simulação (herdada do app original) e entra
sempre com o e-mail fixo definido no código. Troque por um login real antes de divulgar.
